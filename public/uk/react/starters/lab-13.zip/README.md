# ЛР-13. Налаштування React-маршрутизації, захищених роутів та лінивого завантаження

Стартовий проєкт лабораторної роботи № 13 курсу «Розробка вебзастосунків на
React»: сайт кінотеатру з готовими сторінками й блог-приклад до §4.3.
Інструкція: https://denysmatsevych.github.io/web-development-2026/react/labs/lab-13/

Сторінки сайту вже написано: «Афіша», сторінка фільму, «Розклад», «Вхід»,
«Бронювання» зі схемою зали, «Кабінет» з «Профілем» і «Моїми квитками».
Маршрут поки один: «Афіша» на адресі `/`, без шапки сайту. У чотирьох code
challenges ви налаштуєте маршрути React Router між сторінками: спільний
макет і сторінку фільму за адресою, вкладені маршрути кабінету, захищені
сторінки й ліниве завантаження коду. Що має вийти, перевіряють готові тести
в теці `tests/`.

## Вхід

Вхід несправжній: обліковий запис `glyadach@kino.test` з паролем
`kino2026`. Користувач, який увійшов, зберігається в `sessionStorage`,
квитки — у `localStorage` браузера.

## Що вже є

- `src/app/main.jsx` — рендерить `<App />` в елемент `#root`;
- `src/app/App.jsx` — роутер з маршрутів `src/app/routes.js` у
  `<RouterProvider>`;
- `src/app/routes.js` — один маршрут: `/` → `MoviesPage`;
- `src/app/RootLayout.jsx` — шапка сайту зі звичайними посиланнями `<a>`;
  «Вийти» лише виходить і нікуди не переходить;
- `src/app/authMiddleware.js` — заготовки middleware `requireUser` і
  `guestOnly` з описом у коментарі (§4.6);
- `src/routes/` — сторінки, по теці на маршрут: `movies/`, `movie/`,
  `schedule/`, `login/`, `booking/`, `account/`;
- `src/shared/` — несправжній вхід (`auth/session.js`), фільми, сеанси,
  квитки (`data/`), `safeRedirect` (`utils/`) і спільні
  компоненти (`components/`): «Сторінку не знайдено», сторінка помилки,
  `HydrateFallback`, обкладинка фільму;
- `example/` — блог, на якому §4.3 показує маршрутизацію React Router;
  `DeclarativeApp.jsx` і `main-declarative.jsx` — той самий блог у
  декларативному режимі;
- `MEASUREMENTS.md` — дві таблиці, які ви заповните в §4.7;
- тести Vitest і React Testing Library в `tests/`: по файлу на challenge. `app.jsx` відкриває сайт
  за адресою в `<StrictMode>`, як `src/app/App.jsx`. Файли в `tests/` не
  змінюйте.

## Команди

`npm install` виконуйте в корені репозиторію `react-labs`, решту — у теці
`lab-13/`:

- `npm run dev`: dev-сервер сайту на http://localhost:5173
- `npm run example`: dev-сервер блогу з §4.3; якщо порт 5173 зайнято, Vite
  візьме наступний
- `npm test`: тести в режимі спостереження, вони
  перезапускаються після кожного збереження файлу; `q` — вихід
- `npm test -- tests/routes`: лише тести цього файлу
- `npm test -- --run`: усі тести один раз
- `npm run lint`: ESLint
- `npm run format:check`: перевірка форматування Prettier
- `npm run build`: production-збірка в `dist/`
- `npm run preview`: сервер для збірки з `dist/`
